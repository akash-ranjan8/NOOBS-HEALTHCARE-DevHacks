function signup() {
    alert('You have been registered')
}
